<html>
  <body>
    <h2>%sender_info%</h2>
    <p>%message%</p>
  </body>
</html>
