l = {
  subject_error: "Length of the subject has to be at least 4 symbols long",
  message_error: "Length of the message has to be at least 20 symbols long"
}
